#ifndef TRAFFIC_H
#define TRAFFIC_H

void trafficmeter(const char *iface, unsigned int sampletime);
void livetrafficmeter(const char *iface, const int mode);

#endif
